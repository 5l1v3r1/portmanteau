/*
 * main.h
 * 
 * Portmanteau
 * 
 * Portmanteau Definitions
 * 
 * ./portmanteau -i /usr/src/linux-source-3.2/include/linux/if_tun.h
 * ./portmanteau -u "device_name:/usr/src/linux-source-3.2/include/linux/if_tun.h:/dev/net/tun" 
 *
*/

#include <stdbool.h>

#define NAME    "Portmanteau"
#define VERSION "v1.0"

#define DRIVER_IOCTL_TABLE "drsig_table"
#define DRIVER_IOCTL_DB    "drsig.db"

#define RANDOM_SOURCE "/dev/urandom"

#define DELIMITER ":"

//
// match any #define, followed by any character, then whitespace, supported _IOs and a beginning parenthesis
//
// does not support multi-line #defines
//
#define IOCTL_REGEX "^#define.*\\s_IO[RW]R*\("

#define NOT_FOUND "[not-found]"

#define POC_DIRECTORY "poc"

#define MAX_IOCTL_BUFFER_SIZE 8096

static bool debug = false;

static char errorMsg[256];

static char deviceIoctls[] = {0};
